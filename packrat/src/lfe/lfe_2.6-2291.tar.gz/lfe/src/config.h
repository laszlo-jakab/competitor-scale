/* src/config.h.  Generated from config.h.in by configure.  */
/* #undef HAVE_SEM */
/* #undef NOTHREADS */
/* #undef HUGE_INT */
/* #undef HAVE_THREADNAME */


